#include <stdio.h>
#include "mvar.h"

typedef lnc_req *linklist;
lnc_req *req_head = NULL;
lnc_req *req_tail = NULL;
