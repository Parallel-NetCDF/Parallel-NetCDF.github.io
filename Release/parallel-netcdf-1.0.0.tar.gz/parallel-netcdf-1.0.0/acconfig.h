/* The number of bytes in a off_t */
#undef SIZEOF_OFF_T

/* The number of bytes in a size_t */
#undef SIZEOF_SIZE_T

#undef NCBYTE_T
#undef NCSHORT_T
#undef NF_DOUBLEPRECISION_IS_C_
#undef NF_INT1_IS_C_
#undef NF_INT1_T
#undef NF_INT2_IS_C_
#undef NF_INT2_T
#undef NF_INT_IS_C_
#undef NF_REAL_IS_C_
#undef NO_IEEE_FLOAT
#undef NO_STRERROR
