## GIO Release Notes

### Version _GIO_VERSION_ (_GIO_RELEASE_DATE_)

* Bug fix
  + Fix the bug when opening a file that uses the Lustre's Progressive File
    Layout (PFL). To test this bug, a test program `test/tst_pfl.c` is added
    as well as its compile/run script file, `test/run_tst_pfl.sh`.
    See [PR #2](https://github.com/wkliao/gio/pull/2) and
    [PnetCDF #234](https://github.com/Parallel-NetCDF/PnetCDF/issues/234)


### Version 1.0.0 (June 27, 2026)

* The first release of GIO library version 1.0.0.
* The source code repository is at https://github.com/wkliao/gio
* Refer to [C API references](docs/APIs.md) for API usage.
* Refer to [I/O hints](docs/hints.md) for I/O hints supported by GIO.
* A list of GIO [utility programs](./utils/README.md) are available.

---

