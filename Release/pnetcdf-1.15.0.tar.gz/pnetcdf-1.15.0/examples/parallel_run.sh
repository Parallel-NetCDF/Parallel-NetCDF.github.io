#!/bin/bash
#
# Copyright (C) 2018, Northwestern University and Argonne National Laboratory
# See COPYRIGHT notice in top-level directory.
#

# Exit immediately if a command exits with a non-zero status.
# set -e

DRY_RUN=no
VERBOSE=no

exe_cmd() {
   local lineno=${BASH_LINENO[$((${#BASH_LINENO[@]} - 2))]}

   cmd=`basename $1`
   if test "x$MIMIC_LUSTRE" = x1 && test "x$cmd" = xncmpidiff ; then
      # echo "export MIMIC_STRIPE_SIZE=1048576"
      export MIMIC_STRIPE_SIZE=1048576
   fi

   if test "x$VERBOSE" = xyes || test "x$DRY_RUN" = xyes ; then
      echo "Line $lineno CMD: $MPIRUN $@"
   fi
   if test "x$DRY_RUN" = xno ; then
      $MPIRUN $@
   fi
   if test $? != 0 ; then
      echo "FAIL: nprocs=$1 ---- $i $TEST_OPTS"
      exit 1
   fi

   if test "x$MIMIC_LUSTRE" = x1 && test "x$cmd" = xncmpidiff ; then
      # echo "unset MIMIC_STRIPE_SIZE"
      unset MIMIC_STRIPE_SIZE
   fi
}

seq_cmd() {
   local lineno=${BASH_LINENO[$((${#BASH_LINENO[@]} - 2))]}
   if test "x$VERBOSE" = xyes || test "x$DRY_RUN" = xyes ; then
      echo "Line $lineno CMD: $TESTSEQRUN $@"
   fi
   if test "x$DRY_RUN" = xno ; then
      $TESTSEQRUN $@
   fi
}

VALIDATOR=../../src/utils/ncvalidator/ncvalidator
NCMPIDIFF=../../src/utils/ncmpidiff/ncmpidiff

MPIRUN=`echo ${TESTMPIRUN} | ${SED} -e "s/NP/$1/g"`
# echo "MPIRUN = ${MPIRUN}"
# echo "check_PROGRAMS=${check_PROGRAMS}"

# remove file system type prefix if there is any
OUTDIR=`echo "$TESTOUTDIR" | cut -d: -f2-`

# let NTHREADS=$1*6-1
NTHREADS=`expr $1 \* 6 - 1`

if test "x$ENABLE_GIO" = x0 ; then
   IO_MODES="mpiio"
else
   IO_MODES="gio mpiio"
   if test "x$GIO_ONLY" = x1 ; then
      IO_MODES="gio"
   fi
fi

# prevent user environment setting of PNETCDF_HINTS to interfere
unset PNETCDF_HINTS

PNETCDF_DEBUG_MODE=`grep PNETCDF_DEBUG_MODE ${top_builddir}/src/include/pnetcdf.h | tr -s ' ' | cut -d ' ' -f 3`

for i in ${check_PROGRAMS} ; do
    # Capture start time in seconds and nanoseconds
    start_time=$(date +%s.%1N)

    VERIFY_OUT_FILE=
    VERIFY_OUT_FILE_PTHREAD=

    if test "$i" = create_from_cdl ; then
       DIFF_OPT="-q -h"
    else
       DIFF_OPT="-q"
    fi

    if test "${PNETCDF_DEBUG_MODE}" = 1 ; then # test only in safe mode
       safe_hint="  SAFE"
    else
       safe_hint="NOSAFE"
    fi
    OUT_PREFIX="${TESTOUTDIR}/$i"

    for io_mode in $IO_MODES ; do
        if test "x$io_mode" = xmpiio ; then
           USEMPIO_HINTS="nc_driver=mpiio"
           DRIVER_OUT_FILE="${OUT_PREFIX}.mpio"
           driver_hint=" MPIO"
        else
           USEMPIO_HINTS="nc_driver=gio"
           DRIVER_OUT_FILE="${OUT_PREFIX}.gio"
           driver_hint="GIO"
        fi

    for intra_aggr in 0 1 ; do
        if test "$intra_aggr" = 1 ; then
           INA_HINTS="nc_num_aggrs_per_node=2"
           INA_OUT_FILE="${DRIVER_OUT_FILE}.ina"
           ina_hint="  INA"
        else
           INA_HINTS="nc_num_aggrs_per_node=0"
           INA_OUT_FILE="${DRIVER_OUT_FILE}.noina"
           ina_hint="NOINA"
        fi

        OUT_FILE=$INA_OUT_FILE

        PNETCDF_HINTS=
        if test "x$USEMPIO_HINTS" != x ; then
           PNETCDF_HINTS="$USEMPIO_HINTS;$PNETCDF_HINTS"
        fi
        if test "x$INA_HINTS" != x ; then
           PNETCDF_HINTS="$INA_HINTS;$PNETCDF_HINTS"
        fi
        if test "x$MIMIC_LUSTRE" != x1 ; then
           PNETCDF_HINTS="cb_nodes=2;$PNETCDF_HINTS"
        fi

        export PNETCDF_HINTS="$PNETCDF_HINTS"
        if test "x$VERBOSE" = xyes || test "x$DRY_RUN" = xyes ; then
           echo "Line ${LINENO}: PNETCDF_HINTS=$PNETCDF_HINTS"
        fi

        TEST_OPTS="$safe_hint $driver_hint $ina_hint"

        CMD_OPT=-q
        IN_FILE=
        if test "$i" = create_from_cdl ; then
           IN_FILE=${srcdir}/cdl_header.txt
        fi

        if test "$i" = pthread ; then
           # each MPI process created 6 threads
           exe_cmd ./$i $CMD_OPT ${OUT_FILE}.nc
           for k in `seq 0 ${NTHREADS}` ; do
               seq_cmd ${VALIDATOR} -q ${OUT_FILE}.nc.$k
           done

           if test "x$VERIFY_OUT_FILE_PTHREAD" = x ; then
              VERIFY_OUT_FILE_PTHREAD=${OUT_FILE}.nc
           else
              for j in `seq 0 ${NTHREADS}` ; do
                  exe_cmd $NCMPIDIFF $DIFF_OPT $VERIFY_OUT_FILE_PTHREAD.$j $OUT_FILE.nc.$j
              done
           fi
           continue
        elif test "$i" = put_vara ; then
           exe_cmd ./$i $CMD_OPT ${OUT_FILE}.nc
           seq_cmd ${VALIDATOR} -q ${OUT_FILE}.nc

           exe_cmd ./get_vara $CMD_OPT ${OUT_FILE}.nc
        elif test "$i" = get_vara ; then
           continue
        elif test "$i" = create_from_cdl ; then
           # create_from_cdl reads a CDL header file
           exe_cmd ./$i $CMD_OPT -o ${OUT_FILE}.nc $IN_FILE
        else
           exe_cmd ./$i $CMD_OPT ${OUT_FILE}.nc
        fi

        seq_cmd ${VALIDATOR} -q ${OUT_FILE}.nc

        if test "x$VERIFY_OUT_FILE" = x ; then
           VERIFY_OUT_FILE=${OUT_FILE}
        else
           exe_cmd ${NCMPIDIFF} $DIFF_OPT $VERIFY_OUT_FILE.nc $OUT_FILE.nc
        fi

        if test "x${ENABLE_BURST_BUFFER}" = x1 ; then
           saved_PNETCDF_HINTS=${PNETCDF_HINTS}
           export PNETCDF_HINTS="${PNETCDF_HINTS};nc_burst_buf=enable;nc_burst_buf_dirname=${TESTOUTDIR};nc_burst_buf_overwrite=enable"
           if test "$i" = create_from_cdl ; then
              # create_from_cdl reads a CDL header file
              exe_cmd ./$i -q -o ${OUT_FILE}.bb.nc $IN_FILE
           else
              exe_cmd ./$i $CMD_OPT ${OUT_FILE}.bb.nc
           fi
           export PNETCDF_HINTS=${saved_PNETCDF_HINTS}

           seq_cmd ${VALIDATOR} -q ${OUT_FILE}.bb.nc

           # compare file header only for large file tests
           exe_cmd ${NCMPIDIFF} $DIFF_OPT $VERIFY_OUT_FILE.nc $OUT_FILE.bb.nc
        fi

        if test "x${ENABLE_NETCDF4}" = x1 ; then
           exe_cmd ./$i ${OUT_FILE}.nc4 4
           # Validator does not support nc4
        fi
    done # intra_aggr
    done # io_mode

    if test "$i" = get_vara ; then
       continue
    fi

    rm -f ${OUTDIR}/$i*nc*

    end_time=$(date +%s.%1N)

    # Calculate difference (requires bc for floating point math)
    elapsed_time=$(echo "$end_time - $start_time" | bc)

    fixed_length=48
    printf "*** TESTING  %-${fixed_length}s   -- pass (%4ss)\n" "$i" "$elapsed_time"

done # check_PROGRAMS

